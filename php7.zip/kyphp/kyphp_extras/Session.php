<?php
// +----------------------------------------------------------------------
// ���ݵ�php���
// +----------------------------------------------------------------------
// | Copyright (c) 2011 http://www.ky53.net All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.ky53.net )
// +----------------------------------------------------------------------

/**
 
 * @author   qq:974005652(zhx626@126.com) by����ͯ
 * @version  2.0
 +------------------------------------------------------------------------------
 */
final class Session {
	public $data = array();
			
  	public function __construct() {
		
		
		if (!session_id()) {
			ini_set('session.use_cookies', 'On');
			ini_set('session.use_trans_sid', 'Off');
		
			session_set_cookie_params(0, '/');
			
			session_start();
			
			
		}
		
		$this->data =& $_SESSION;
	}
}
?>