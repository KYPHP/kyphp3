<?php
function getsh($name='0'){
  
   if($name=='1'){
     $str='是';
   }else{
     $str='否';
   }
   return $str;
}
?>