<?php
class publicAction extends Action {
	
	
	
}
?>