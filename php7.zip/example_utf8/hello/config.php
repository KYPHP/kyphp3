<?php
if (!defined('KY_PATH'))	exit();


$array = array(
    'title'=>'hello word!',
);
return $array;
?>