<?php
class classAction extends cmdAction {
   
   public function _initialize(){
   
   $this->getform('sort');
  
   }
  
    
	
}
?>