<?php
class indexAction extends publicAction {
   
   public function _initialize(){
	//echo "111";
   }
   public function index(){
    
	  
      $this->display();

   }
    
	
}
?>