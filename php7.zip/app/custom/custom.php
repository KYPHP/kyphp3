<?php
class custom {
	public $blog="这是一个自定义类的例子！我在custom/custom.php";//这是一个自定义的类，在这里可以是该项目最顶层的类，也可以是其它自定义类，可以在项目中用$this->custom('类名')




}