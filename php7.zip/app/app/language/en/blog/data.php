<?php
// Heading 
$_['sitename']      = 'This is a Blog !';




 
?>
