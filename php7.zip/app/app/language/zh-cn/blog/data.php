<?php
// Heading 
$_['sitename']      = '这是一个博客示例 !';




 
?>
