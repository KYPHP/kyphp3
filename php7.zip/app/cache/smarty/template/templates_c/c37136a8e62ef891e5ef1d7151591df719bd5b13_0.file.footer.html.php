<?php
/* Smarty version 3.1.29, created on 2016-01-12 07:34:05
  from "/data/app/www/php7/app/app/tpl/default/public/footer.html" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_5694ac6d89f885_15223231',
  'file_dependency' => 
  array (
    'c37136a8e62ef891e5ef1d7151591df719bd5b13' => 
    array (
      0 => '/data/app/www/php7/app/app/tpl/default/public/footer.html',
      1 => 1410066933,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5694ac6d89f885_15223231 ($_smarty_tpl) {
?>

 
<div class="Footer">
<p>Powered by <a href="<?php echo $_smarty_tpl->tpl_vars['http']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['sitename']->value;?>
</a></p>
</div>

</div></div>


		

<div id="wpadminbar">
			<div class="quicklinks">
				<ul>
													
		<li id="wp-admin-bar-site" class="">
			

			
					</li>													
		<li id="wp-admin-bar-login" class="">
			

			
					</li>													
		<li id="wp-admin-bar-sign-up" class="">
			

			
					</li>													
		<li id="wp-admin-bar-random-blog" class="">
			

			
					</li>													
		<li id="wp-admin-bar-report-blog" class="">
			</li>									</ul>
			</div>

		</div></body></html><?php }
}
