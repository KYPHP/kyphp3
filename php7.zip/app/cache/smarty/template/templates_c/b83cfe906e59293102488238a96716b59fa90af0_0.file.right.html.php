<?php
/* Smarty version 3.1.29, created on 2016-01-12 07:34:05
  from "/data/app/www/php7/app/app/tpl/default/public/right.html" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_5694ac6d8a4b46_61126557',
  'file_dependency' => 
  array (
    'b83cfe906e59293102488238a96716b59fa90af0' => 
    array (
      0 => '/data/app/www/php7/app/app/tpl/default/public/right.html',
      1 => 1383478925,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5694ac6d8a4b46_61126557 ($_smarty_tpl) {
?>



<div class="Nav">
</div>
 
</div>
<!--  Side SC END -->

</div>
<!--  Side ContentWrapper END -->

<!-- Side Right - START -->
<div class="SR">

<!-- START Search -->
<div class="Search">
 <h3>Search</h3>
    <form action="" method="post">
     <input type="text" name="s" class="keyword" style="width: 198px;">
    </form>
 <div class="SearchCorner"></div>
</div>
<!-- END Search -->
				
				<div id="ads-placeholder"><div id="azk71839"></div></div><div class="Categories"><h3>Blogroll</h3>
	<ul class="xoxo blogroll">
<li><a href="http://www.2inc.net/Costumes-cid-216/Cosplay-Wigs-cid-221" title="Cosplay Wigs">Cosplay Wigs</a></li>
<li><a href="http://www.2inc.net/Costumes-cid-216" title="halloween costumes">halloween costumes</a></li>
<li><a href="http://www.2inc.net/Costumes-cid-216/Mascot-Costumes-cid-218" title="Halloween mascot Costumes">Halloween mascot Costumes</a></li>
<li><a href="http://www.2inc.net/Mascot-Costumes-cid-61" title="Mascot Costumes">Mascot Costumes</a></li>
<li><?php echo $_smarty_tpl->tpl_vars['test']->value;?>
</li>

	</ul>
</div>
</div> 
<!-- Side Right - END -->
<?php }
}
